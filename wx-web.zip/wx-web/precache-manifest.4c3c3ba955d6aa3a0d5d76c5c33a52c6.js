self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c3c19a066f3cf9ea8c0d29a9f12ad3d8",
    "url": "../wx-web/index.html"
  },
  {
    "revision": "67010a2acc0a584bfa6f5de212fb92fd",
    "url": "../wx-web/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "../wx-web/robots.txt"
  },
  {
    "revision": "8ad816d068a7d4830d28",
    "url": "../wx-web/static/css/app.1d7592ee.css"
  },
  {
    "revision": "c76271342d048107223b",
    "url": "../wx-web/static/css/chunk-vendors.6fa941d1.css"
  },
  {
    "revision": "6cf5fb04c6d243d14c98b42b64026a71",
    "url": "../wx-web/static/img/u45.6cf5fb04.png"
  },
  {
    "revision": "8ad816d068a7d4830d28",
    "url": "../wx-web/static/js/app.b8ab8041.js"
  },
  {
    "revision": "c76271342d048107223b",
    "url": "../wx-web/static/js/chunk-vendors.9a6b7649.js"
  },
  {
    "revision": "775529c69d2d5632895cc05e924780bb",
    "url": "../wx-web/wx/jweixin-1.6.0.js"
  }
]);